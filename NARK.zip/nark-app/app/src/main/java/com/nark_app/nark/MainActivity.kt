package com.nark_app.nark

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)
	}
	
	private val youtube get() = GeoAppBlocker.getApplication(this, "com.google.android.youtube")
	
	fun blockYouTube(view: View) {
		youtube.blocked = true
	}
	
	fun unblockYouTube(view: View) {
		youtube.blocked = false
	}
	
	fun enableBlocker(view: View) {
		GeoAppBlocker.enabled = true
	}
	
	fun disableBlocker(view: View) {
		GeoAppBlocker.enabled = false
	}
	
	
	
	fun debugBreakpoint(view: View) {
		return
	}
}
