package com.nark_app.nark

import android.accessibilityservice.*
import android.view.accessibility.*
import android.content.*
import android.content.pm.*
import android.graphics.drawable.Drawable
import android.location.*
import android.util.Log
import android.widget.Toast
import com.google.android.gms.location.*
import com.google.android.gms.tasks.*

/**
 * Accessibility service for blocking apps.
 */
object GeoAppBlocker {
	// TODO: Sort out obtaining the correct permissions
	
	// TODO: This needs to be stored somewhere persistent
	private val blockedApplications = object : MutableSet<String> by mutableSetOf() {
		fun add(application: ApplicationInfo) = add(application.packageName)
		fun remove(application: ApplicationInfo) = add(application.packageName)
		
		operator fun contains(application: ApplicationInfo) = contains(application.packageName)
		
		operator fun plus(application: ApplicationInfo) = plus(application.packageName)
		operator fun plusAssign(application: ApplicationInfo) = plusAssign(application.packageName)
		
		operator fun minus(application: ApplicationInfo) = minus(application.packageName)
		operator fun minusAssign(application: ApplicationInfo) = minusAssign(application.packageName)
	}
	
	var enabled = true // TODO: This needs to be stored somewhere persistent
	
	// TODO: Implement logic for this
	private val blockedLocations = object {
		operator fun contains(location: Location) = true // Every location is blocked for testing
	}
	
	private const val applicationInfoFlags = PackageManager.GET_META_DATA
	
	fun getApplications(context: Context) = context.packageManager
		.getInstalledApplications(applicationInfoFlags).map {
			GeoAppBlockerApplicationInfo(it, context.packageManager)
		}
	
	fun getApplication(context: Context, packageName: String) = context.packageManager
		.getApplicationInfo(packageName, applicationInfoFlags).let {
			GeoAppBlockerApplicationInfo(it, context.packageManager)
		}
	
	class GeoAppBlockerApplicationInfo(orig: ApplicationInfo, private val packageManager: PackageManager) :
		ApplicationInfo(orig) {
		var blocked: Boolean
			get() = this in blockedApplications
			set(block) = when (block) {
				true -> blockedApplications += this
				false -> blockedApplications -= this
			}
		
		val banner: Drawable? get() = loadBanner(packageManager)
		val description: CharSequence? get() = loadDescription(packageManager)
		val icon: Drawable? get() = loadIcon(packageManager)
		val label: CharSequence get() = loadLabel(packageManager)
		val logo: Drawable? get() = loadLogo(packageManager)
		val unbadgedIcon: Drawable? get() = loadUnbadgedIcon(packageManager)
	}
	
	fun unblockAll() = blockedApplications.clear()
	
	class GeoAppBlockerService : AccessibilityService() {
		private var currentLocationTask: Task<Location>? = null
		private lateinit var currentApplication: GeoAppBlockerApplicationInfo
		
		private fun runLocationTask() {
			if (currentLocationTask?.isComplete != false) {
				currentLocationTask = try {
					LocationServices.getFusedLocationProviderClient(this).lastLocation.apply {
						addOnSuccessListener { location ->
							if (currentApplication in blockedApplications) when (location) {
								null -> Log.w(null, "No location available")
								in blockedLocations -> {
									// TODO: Block launch of app
									Toast.makeText(
										this@GeoAppBlockerService,
										"${currentApplication.label} is blocked",
										Toast.LENGTH_SHORT
									).show()
								}
							}
						}
						
						addOnFailureListener { e ->
							Log.e(null, "Failure obtaining location: $e")
						}
						
						addOnCanceledListener {
							Log.e(null, "Obtaining location canceled")
						}
					}
				} catch (e: SecurityException) {
					Log.e(null, "SecurityException obtaining location: $e")
					null
				}
			}
		}
		
		override fun onAccessibilityEvent(event: AccessibilityEvent?) {
			when (event?.eventType) {
				AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
					currentApplication = getApplication(this, event.packageName.toString())
					
					if (enabled && currentApplication in blockedApplications) {
						runLocationTask()
					}
				}
				else -> Unit
			}
		}
		
		override fun onInterrupt() {
			// TODO: Close any popups? Make sure we don't stay at the blocked app though.
		}
	}
}


