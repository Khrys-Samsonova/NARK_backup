include(":app")
rootProject.name = "NARK"
